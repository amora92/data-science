# Bioinformatics - Extra Resources

# Paid Books
* Biological Sequence Analysis (R. Durbin et al)
* Bioinformatics and Functional Genomics (J. Pevsner)
* BioInfoBook [Figures](http://bioinfbook.org/php/powerpoints)
* [Bioinformatic Algorithms](http://bioinformaticsalgorithms.com/)
