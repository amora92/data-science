# Bioinformatics - Extra Resources

# Paid Courses
[Micro-masters in Bioinformatics from University of Maryland](https://www.edx.org/micromasters/bioinformatics)
