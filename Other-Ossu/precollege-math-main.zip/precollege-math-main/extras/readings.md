# Pre-College Math - Great Readings

This document consists of great books or articles on pre-college math.
Some are here because there is a course covering the same material;
some are just great books that you should read at some point in your career.

Once you have made it through most of the curriculum, knowing whether a book is worth your time will become easier.
Or, if you are struggling in one of the courses, perhaps reading a book on the subject will help.

Name | Author(s)
:-- | :--:
[Prealgebra](https://openstax.org/details/books/prealgebra-2e) | OpenStax
[Elementary Algebra](https://openstax.org/details/books/elementary-algebra-2e) | OpenStax
[Intermediate Algebra](https://openstax.org/details/books/intermediate-algebra-2e) | OpenStax
[Precalculus](https://openstax.org/details/books/precalculus-2e) | OpenStax