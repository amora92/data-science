# Curricular Guidelines

[Mathematics Common Core Standards](https://www.thecorestandards.org/Math/)

Our curricular guidelines are from the US Common Core Mathematics Standard.

## Organizations publishing:

### Council of Chief State School Officers

The Council of Chief State School Officers (CCSSO) is a non-partisan, non-profit organization of public officials who head departments of elementary and secondary education in the U.S. states, the District of Columbia, the Department of Defense Education Activity, the Bureau of Indian Education, and five U.S. territories.

### National Governors Association

The National Governors Association (NGA) is an American political organization founded in 1908. The association's members are the governors of the 55 states, territories and commonwealths. Members come from across the political spectrum. NGA declares itself as nonpartisan.
